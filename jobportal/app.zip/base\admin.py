from django.contrib import admin

from .models import Job,Category

admin.site.register(Job)
admin.site.register(Category)
